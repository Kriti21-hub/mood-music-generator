# === GLOBAL TIMING ===
PPQ = 480                  # ticks per quarter note
TIME_SIGNATURE = (4, 4)    # 4/4
DEFAULT_BARS = 16          # default song length
STEPS_PER_BAR = 16         # 16 steps per bar (1/16 notes)

# === SOUND ===
SOUNDFONT_PATH = "FluidR3_GM.sf2"  # downloaded above (optional for WAV)

# === MIDI CHANNELS (0-indexed; drums must be 9 for GM) ===
CHANNELS = {
    "melody": 0,
    "chords": 1,
    "bass":   2,
    "pad":    3,
    "drums":  9,  # GM drums
}

# === GENERAL MIDI PROGRAMS (0..127) ===
PROGRAMS = {
    "piano":        0,   # Acoustic Grand (GM 1)
    "epiano1":      4,   # Electric Piano 1 (GM 5)
    "nylon_guitar": 24,  # Acoustic Guitar Nylon (GM 25)
    "strings":      48,  # String Ensemble 1 (GM 49)
    "warm_pad":     89,  # Pad 2 (Warm) (GM 90)
    "saw_lead":     81,  # Lead 2 (Saw) (GM 82)
    "acoustic_bass":32,  # Acoustic Bass (GM 33)
    "synth_bass":   38,  # Synth Bass 1 (GM 39)
}

# === DRUM NOTE NUMBERS (General MIDI on channel 10) ===
DRUM_NOTES = {
    "kick":       36,
    "snare":      38,
    "hh_closed":  42,
    "hh_open":    46,
}

# 16-step patterns per bar (1=hit, 0=rest)
DRUM_PATTERNS = {
    "Happy": {
        "kick":      [1,0,0,0, 0,0,1,0, 1,0,0,0, 0,0,1,0],
        "snare":     [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hh_closed": [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1],
        "hh_open":   [0]*16,
    },
    "Chill": {
        "kick":      [1,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,0],
        "snare":     [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hh_closed": [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,0],
        "hh_open":   [0]*16,
    },
    "Focus": {
        "kick":      [1,0,0,0, 0,0,1,0, 1,0,0,0, 0,0,1,0],
        "snare":     [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hh_closed": [1,0,1,0, 1,0,1,0, 1,0,1,0, 1,0,1,0],
        "hh_open":   [0]*16,
    },
    "Sad": {
        "kick":      [1,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,0],
        "snare":     [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hh_closed": [1,0,0,0, 0,0,1,0, 0,0,1,0, 0,0,1,0],
        "hh_open":   [0]*16,
    },
    "Energetic": {
        "kick":      [1,0,0,1, 0,1,0,0, 1,0,0,1, 0,1,0,0],
        "snare":     [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "hh_closed": [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1],
        "hh_open":   [0,0,0,0, 0,0,1,0, 0,0,0,0, 0,0,1,0],
    },
}

# === MOOD MAP (keys, bpm, progression, instruments, densities) ===
MOODS = {
    "Happy": {
        "keys": ["C","G","D"],
        "mode": "Major",
        "bpm_range": (118, 126),
        "progression": ["I","V","vi","IV"],  # 4 bars, repeats
        "swing_pct": 0.0,
        "humanize_ms": 8,
        "instruments": {"chords":"piano","pad":"warm_pad","melody":"nylon_guitar","bass":"acoustic_bass","drums":True},
        "velocity": {"chords":(70,100),"pad":(50,80),"melody":(80,110),"bass":(75,100),"drums":(80,110)},
        "density": {"melody":0.7,"chords":0.9,"pad":0.4,"bass":0.8},
    },
    "Chill": {
        "keys": ["D","F"],
        "mode": "Dorian_or_Lydian",  # pick one later
        "bpm_range": (74, 86),
        "progression": ["i","VII","IV"],
        "swing_pct": 7.5,
        "humanize_ms": 12,
        "instruments": {"chords":"epiano1","pad":"warm_pad","melody":"epiano1","bass":"acoustic_bass","drums":True},
        "velocity": {"chords":(55,80),"pad":(45,70),"melody":(55,85),"bass":(55,80),"drums":(50,80)},
        "density": {"melody":0.4,"chords":0.6,"pad":0.6,"bass":0.5},
    },
    "Focus": {
        "keys": ["A"],
        "mode": "Aeolian",
        "bpm_range": (90, 100),
        "progression": ["i","iv","v","iv"],
        "swing_pct": 0.0,
        "humanize_ms": 6,
        "instruments": {"chords":"epiano1","pad":"strings","melody":"epiano1","bass":"acoustic_bass","drums":True},
        "velocity": {"chords":(60,85),"pad":(50,75),"melody":(60,85),"bass":(60,85),"drums":(60,85)},
        "density": {"melody":0.5,"chords":0.7,"pad":0.5,"bass":0.7},
    },
    "Sad": {
        "keys": ["E"],
        "mode": "Aeolian",
        "bpm_range": (66, 78),
        "progression": ["i","VI","III","VII"],
        "swing_pct": 0.0,
        "humanize_ms": 10,
        "instruments": {"chords":None,"pad":None,"melody":"piano","bass":None,"drums":False},
        "velocity": {"melody":(50,80)},
        "density": {"melody":0.35},
    },
    "Energetic": {
        "keys": ["A"],
        "mode": "Mixolydian",
        "bpm_range": (128, 140),
        "progression": ["I","bVII","IV","I"],
        "swing_pct": 0.0,
        "humanize_ms": 5,
        "instruments": {"chords":"saw_lead","pad":"warm_pad","melody":"saw_lead","bass":"synth_bass","drums":True},
        "velocity": {"chords":(85,115),"pad":(60,90),"melody":(90,120),"bass":(85,115),"drums":(85,120)},
        "density": {"melody":0.8,"chords":0.9,"pad":0.5,"bass":0.9},
    },
}
