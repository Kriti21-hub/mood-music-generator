# Build MIDI from events, and optionally render to WAV with FluidSynth.
import mido
from typing import Dict, List, Tuple
from config import PPQ, CHANNELS, PROGRAMS, SOUNDFONT_PATH, STEPS_PER_BAR
from theory import steps_to_ticks

Event = Tuple[int,int,int,int]  # (start_step, dur_steps, midi_note, velocity)

def _add_tempo(track, bpm:int):
    mpqn = int(60_000_000 / bpm)  # microseconds per quarter
    track.append(mido.MetaMessage('set_tempo', tempo=mpqn, time=0))

def _events_to_track(events:List[Event], channel:int) -> mido.MidiTrack:
    # Sort by start then note_off ordering
    # Build delta times from absolute steps
    track = mido.MidiTrack()
    # Convert to a list of (abs_tick, on/off, note, velocity)
    pairs = []
    for (start_s, dur_s, note, vel) in events:
        start_t = steps_to_ticks(start_s)
        end_t   = steps_to_ticks(start_s + max(1, dur_s))
        pairs.append((start_t, True,  note, vel))
        pairs.append((end_t,   False, note, vel))
    pairs.sort(key=lambda x: (x[0], not x[1]))  # note_off before note_on at same time
    # Build delta times
    last = 0
    for t, is_on, note, vel in pairs:
        dt = t - last
        last = t
        if is_on:
            track.append(mido.Message('note_on', note=note, velocity=vel, time=dt, channel=channel))
        else:
            track.append(mido.Message('note_off', note=note, velocity=vel, time=dt, channel=channel))
    return track

def make_midi(tracks:Dict[str, List[Event]], program_map:Dict[str,str], out_path:str="mood.mid") -> str:
    mid = mido.MidiFile(ticks_per_beat=PPQ)
    # meta
    meta_track = mido.MidiTrack(); mid.tracks.append(meta_track)
    # tempo from _meta
    meta = dict(tracks.get("_meta", []))
    bpm = int(meta.get("bpm", 120))
    _add_tempo(meta_track, bpm)

    # For each role -> channel -> program
    for role, events in tracks.items():
        if role.startswith("_"):
            continue
        ch = CHANNELS[role]
        t = _events_to_track(events, ch)
        # Set program if not drums
        if role != "drums":
            program_name = program_map.get(role)
            if program_name is not None:
                prog_num = PROGRAMS[program_name]
                t.insert(0, mido.Message('program_change', program=prog_num, time=0, channel=ch))
        mid.tracks.append(t)

    mid.save(out_path)
    return out_path

def render_wav_from_midi(midi_path:str, wav_path:str="mood.wav", soundfont:str=SOUNDFONT_PATH) -> str:
    # Uses FluidSynth to convert MIDI -> WAV. Requires soundfont file.
    import pyfluidsynth
    fs = pyfluidsynth.Synth()
    sfid = fs.sfload(soundfont)
    fs.start()
    fs.midi_file_to_audio(midi_path, wav_path)
    fs.delete()
    return wav_path
