# Simple music theory helpers.

from typing import List, Tuple
from config import PPQ, STEPS_PER_BAR

# Semitone offsets for modes (relative to tonic)
MODE_INTERVALS = {
    "Major":       [0,2,4,5,7,9,11],   # Ionian
    "Aeolian":     [0,2,3,5,7,8,10],   # Natural minor
    "Dorian":      [0,2,3,5,7,9,10],
    "Lydian":      [0,2,4,6,7,9,11],
    "Mixolydian":  [0,2,4,5,7,9,10],
}

# Map tonic name to semitone offset from C (no accidentals beyond #/b)
TONIC_OFFSETS = {
    "C":0,"C#":1,"Db":1,"D":2,"D#":3,"Eb":3,"E":4,"F":5,"F#":6,"Gb":6,
    "G":7,"G#":8,"Ab":8,"A":9,"A#":10,"Bb":10,"B":11
}

def build_scale(tonic:str, mode:str, base_octave:int=4) -> List[int]:
    """Return 7 MIDI notes for the scale in a given octave (C4=60)."""
    if mode not in MODE_INTERVALS:
        raise ValueError(f"Unknown mode: {mode}")
    if tonic not in TONIC_OFFSETS:
        raise ValueError(f"Unknown tonic: {tonic}")
    c4 = 60  # MIDI for C4
    tonic_base = (c4 // 12) * 12 + TONIC_OFFSETS[tonic] + (base_octave - 4) * 12
    return [tonic_base + i for i in MODE_INTERVALS[mode]]

def degree_to_midi(scale:List[int], degree:int, octave_shift:int=0) -> int:
    """Degree = 1..7. octave_shift can move up/down by 12 semitones."""
    idx = (degree - 1) % 7
    return scale[idx] + (octave_shift * 12)

def triad_from_degree(scale:List[int], degree:int, octave_shift:int=0) -> Tuple[int,int,int]:
    """Return (root, third, fifth) MIDI for the given degree."""
    root = degree_to_midi(scale, degree, octave_shift)
    third = degree_to_midi(scale, ((degree+2-1)%7)+1, octave_shift)   # +2 scale steps
    fifth = degree_to_midi(scale, ((degree+4-1)%7)+1, octave_shift)   # +4 scale steps
    return (root, third, fifth)

def roman_to_degree(token:str) -> Tuple[int, int]:
    """
    Convert roman like 'I','vi','bVII' -> (degree 1..7, accidental in semitones).
    accidental: -1 for 'b' flat, +1 for '#' sharp. We only support 'b' here.
    """
    accidental = 0
    if token.startswith("b"):
        accidental = -1
        token = token[1:]
    base = token.strip().upper()
    mapping = {"I":1,"II":2,"III":3,"IV":4,"V":5,"VI":6,"VII":7}
    if base not in mapping:
        raise ValueError(f"Unknown roman degree: {token}")
    return mapping[base], accidental

# ---- timing helpers ----
def steps_to_ticks(steps:int) -> int:
    """Convert grid steps to MIDI ticks (1 step = 1/16 note)."""
    ticks_per_step = PPQ // 4  # since 1 quarter has 4 sixteenth notes
    return steps * ticks_per_step
