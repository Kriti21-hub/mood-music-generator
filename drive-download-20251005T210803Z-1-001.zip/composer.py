# Compose a small piece based on mood.
import random
from typing import Dict, List, Tuple
from config import MOODS, DRUM_PATTERNS, STEPS_PER_BAR
from theory import build_scale, triad_from_degree, roman_to_degree, degree_to_midi

# Random helper inside ranges
def rand_in(low:int, high:int) -> int:
    return random.randint(low, high)

def choose_mode(mood_map:Dict) -> str:
    # For Chill, pick Dorian or Lydian randomly
    m = mood_map["mode"]
    if m == "Dorian_or_Lydian":
        return random.choice(["Dorian","Lydian"])
    return m

def build_progression(tonic:str, mode:str, scheme:List[str], bars:int) -> List[Tuple[int,int]]:
    """
    Return list of (degree, accidental) per bar, repeating the scheme to fill bars.
    """
    prog = []
    for i in range(bars):
        token = scheme[i % len(scheme)]
        deg, acc = roman_to_degree(token)
        prog.append((deg, acc))
    return prog

# --- Track event types ---
# For simplicity, we use a common event struct: (start_step, dur_steps, midi_note, velocity)
Event = Tuple[int,int,int,int]

def make_chord_events(scale:List[int], progression:List[Tuple[int,int]], bars:int, velocity:Tuple[int,int]) -> List[Event]:
    events: List[Event] = []
    vmin,vmax = velocity
    for bar, (deg, acc) in enumerate(progression[:bars]):
        # triad in middle octave
        r,t,f = triad_from_degree(scale, deg, octave_shift=0)
        # accidental flat for special roman like bVII (subtract 1 semitone)
        if acc != 0:
            r += acc
            t += acc
            f += acc
        start = bar * STEPS_PER_BAR
        dur = STEPS_PER_BAR  # hold whole bar
        vel = rand_in(vmin, vmax)
        for n in (r,t,f):
            events.append((start, dur, n, vel))
    return events

def make_bass_events(scale:List[int], progression:List[Tuple[int,int]], bars:int, velocity:Tuple[int,int]) -> List[Event]:
    events: List[Event] = []
    vmin,vmax = velocity
    for bar, (deg, acc) in enumerate(progression[:bars]):
        root = degree_to_midi(scale, deg, octave_shift=-1)  # one octave lower
        if acc != 0: root += acc
        start = bar * STEPS_PER_BAR
        half = STEPS_PER_BAR // 2
        vel = rand_in(vmin, vmax)
        # root on beat 1 and 3
        events.append((start, half, root, vel))
        events.append((start+half, half, root, max(vmin, vel-10)))
    return events

def make_melody_events(scale:List[int], progression:List[Tuple[int,int]], bars:int, velocity:Tuple[int,int], density:float) -> List[Event]:
    """
    Simple rule-based melody:
    - prefers chord tones (1,3,5) on strong beats (step % 4 == 0)
    - uses passing tones on weak beats
    - resolves phrase ends to degree 1 or 5
    """
    events: List[Event] = []
    vmin,vmax = velocity
    for bar, (deg, acc) in enumerate(progression[:bars]):
        # chord tones for this bar
        r,t,f = triad_from_degree(scale, deg, 0)
        if acc != 0: r+=acc; t+=acc; f+=acc
        chord_tones = [r,t,f]
        # choose 8 notes per bar at most (on 16-step grid)
        for step in range(STEPS_PER_BAR):
            strong = (step % 4 == 0)  # strong every 4 steps (quarter notes)
            # decide if we place a note here based on density
            if random.random() < (density * (1.2 if strong else 0.8)):
                if strong:
                    note = random.choice(chord_tones)
                else:
                    # passing tone: move +/-2 semitones from nearest chord tone
                    base = random.choice(chord_tones)
                    note = base + random.choice([-2, -1, 1, 2])
                # clamp melody into a nice range (C4..C6)
                note = max(60, min(84, note))
                # short or medium duration
                dur = random.choice([2, 2, 4])  # mostly 1/8 notes, sometimes 1/4
                vel = rand_in(vmin, vmax)
                events.append((bar*STEPS_PER_BAR + step, dur, note, vel))
        # end of bar: force resolution sometimes
        if random.random() < 0.5:
            resolve = random.choice([degree_to_midi(scale, 1, 0), degree_to_midi(scale, 5, 0)])
            resolve = max(60, min(84, resolve))
            events.append((bar*STEPS_PER_BAR + (STEPS_PER_BAR-2), 2, resolve, rand_in(vmin, vmax)))
    return events

def make_pad_events(scale:List[int], progression:List[Tuple[int,int]], bars:int, velocity:Tuple[int,int]) -> List[Event]:
    # pad holds longer notes (half-bar)
    events: List[Event] = []
    vmin,vmax = velocity
    half = STEPS_PER_BAR // 2
    for bar, (deg, acc) in enumerate(progression[:bars]):
        r,t,f = triad_from_degree(scale, deg, 1)  # one octave up
        if acc != 0: r+=acc; t+=acc; f+=acc
        for h in [0, half]:
            start = bar*STEPS_PER_BAR + h
            vel = rand_in(vmin, vmax)
            for n in (r,t,f):
                events.append((start, half, n, vel))
    return events

def make_drum_events(pattern_name:str, bars:int, velocity:Tuple[int,int]) -> List[Event]:
    # drums use MIDI notes on channel 10 (we'll place "note" as drum note numbers)
    from config import DRUM_PATTERNS, DRUM_NOTES
    vmin,vmax = velocity
    patt = DRUM_PATTERNS[pattern_name]
    events: List[Event] = []
    for bar in range(bars):
        for i in range(STEPS_PER_BAR):
            start = bar*STEPS_PER_BAR + i
            if patt["kick"][i]:  events.append((start, 1, DRUM_NOTES["kick"], rand_in(vmin,vmax)))
            if patt["snare"][i]: events.append((start, 1, DRUM_NOTES["snare"], rand_in(vmin,vmax)))
            if patt["hh_closed"][i]: events.append((start, 1, DRUM_NOTES["hh_closed"], rand_in(vmin,vmax)))
            if patt["hh_open"][i]:   events.append((start, 1, DRUM_NOTES["hh_open"], rand_in(vmin,vmax)))
    return events

def compose(mood_name:str="Happy", bars:int=16, seed:int=None) -> Dict[str, List[Event]]:
    if seed is not None:
        random.seed(seed)
    mood = MOODS[mood_name]
    # choose key + mode
    key = random.choice(mood["keys"])
    mode = mood["mode"]
    if mode == "Dorian_or_Lydian":
        mode = random.choice(["Dorian","Lydian"])
    # build scale (center around octave 4)
    scale = build_scale(key, mode, base_octave=4)
    # build progression per bar
    progression = build_progression(key, mode, mood["progression"], bars)
    # velocities
    vel = mood["velocity"]
    # tracks
    tracks: Dict[str, List[Event]] = {}
    if mood["instruments"].get("chords"):
        tracks["chords"] = make_chord_events(scale, progression, bars, vel["chords"])
    if mood["instruments"].get("bass"):
        tracks["bass"] = make_bass_events(scale, progression, bars, vel["bass"])
    if mood["instruments"].get("pad"):
        tracks["pad"] = make_pad_events(scale, progression, bars, vel["pad"])
    if "melody" in mood["instruments"] and mood["instruments"]["melody"]:
        tracks["melody"] = make_melody_events(scale, progression, bars, vel.get("melody", (70,100)), mood["density"]["melody"])
    if mood["instruments"].get("drums"):
        tracks["drums"] = make_drum_events(mood_name, bars, vel["drums"])
    # also return chosen params for display
    tracks["_meta"] = [("key", key), ("mode", mode), ("bpm", random.randint(*mood["bpm_range"]))]
    return tracks
